#include "scicos_block4.h"
#include "machine.h"

void sim_one(scicos_block *block,int flag)
{
  double *u1, *u2; //** inputs  
  double *y ;      //** output
  double *z ; //** internal discrete state

  int i; 
  double acc ; 

  u1 = GetRealInPortPtrs(block, 1); //** first input port
  u2 = GetRealInPortPtrs(block, 2); //** second input port
  y  = GetRealOutPortPtrs(block,1); //** first output port   
  z  = GetDstate(block) ; //** internal discrete state
  switch (flag)
  {
    case Initialization:
      z[0] = 0.0 ; //** put to zero  
      y[0] = 0.0 ; //** state and output 
    break;

    case OutputUpdate:
      y[0]= z[0] ; 
    break;

    case StateUpdate:
      acc = 0 ; 
      for (i=0; i<3 ; i++)
          acc = acc + u1[i]*u2[i] ; 
       z[0] = z[0] + acc; 
    break;

    case Ending:
       //** do nothing 
    break; 
    
    default:
       //** do nothing
    break;
   } 

}


